/** 
* Creates a customer with a location and a balance.
* 
* Activity 7B 
* @author Cora Baldwin 
* @version March 21, 2022 
*/

public class Customer implements Comparable<Customer> {
   
   // instance variables
   private String name = "";
   private String location = "";
   private double balance = 0;
   
   /**
   * Constructor that creates a new customer.
   * 
   * @param nameIn - name
   */
   public Customer(String nameIn) {
      name = nameIn;
      location = "";
      balance = 0;
   }
   
   /**
   * Method to set the customer's location.
   * 
   * @param locationIn - user input of location
   */
   public void setLocation(String locationIn) {
      location = locationIn;
   }
   
   /**
   * Method to add/subtract from current account balance.
   * 
   * @param amount - user input of change
   */
   public void changeBalance(double amount) {
      balance += amount;
   }
   
   /**
   * Method to return the customer's location.
   * 
   * @return location - customer's location
   */
   public String getLocation() {
      return location;
   }
   
   /**
   * Method to return the account balance.
   * 
   * @return balance - account balance
   */
   public double getBalance() {
      return balance;
   }
   
   /**
   * Method to set location using two parameters.
   * 
   * @param city - user input of city
   * @param state - user input of state
   */
   public void setLocation(String city, String state) {
      location = city + ", " + state;
   }
   
   /**
   * Method to return a summary of the customer.
   * 
   * @return output - summary
   */
   public String toString() {
      String output = name + "\n" + location + "\n$" + balance;
      return output;
   }
   
   /**
   * Method to compare two account balances.
   * 
   * @param obj - user input
   * @return number - depends on result
   */
   public int compareTo(Customer obj) {
      if (Math.abs(this.balance - obj.getBalance()) < 0.000001) {
         return 0;
      }
      else if (this.balance < obj.getBalance()) {
         return -1;
      }
      else {
         return 1;
      }
   }
}