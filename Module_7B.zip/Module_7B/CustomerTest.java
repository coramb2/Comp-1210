import org.junit.Assert;
//import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/** 
* Creates a customer with a location and a balance.
* 
* Activity 7B 
* @author Cora Baldwin 
* @version March 21, 2022 
*/

public class CustomerTest {


  /** Fixture initialization (common initialization
   *  for all tests). **/
   @Before public void setUp() {
   }

   /** A test for setLocationTest1. **/
   @Test public void setLocationTest1() {
      
      Customer c = new Customer("Lane, Jane");
      c.setLocation("Boston, MA");
      Assert.assertEquals("Boston, MA", c.getLocation());
   }
   
   /** A test for setLocationTest2. **/
   @Test public void setLocationTest2() {
      
      Customer c = new Customer("Lane, Jane");
      c.setLocation("Atlanta", "GA");
      Assert.assertEquals("Atlanta, GA", c.getLocation());
   }
   
   /** A test for changeBalanceTest. **/
   @Test public void changeBalanceTest() {
      
      Customer c = new Customer("Lane, Jane");
      c.changeBalance(100);
      Assert.assertEquals(100, c.getBalance(), 0.000001);
   }
   
   /** A test for toStringTest. **/
   @Test public void toStringTest() {
    
      Customer c = new Customer("Lane, Jane");
      c.setLocation("Auburn, AL");
      c.changeBalance(999);
      Assert.assertEquals("Lane, Jane\nAuburn, AL\n$999.0", c.toString());
   }
   
   /** A test for compareToTest1. **/
   @Test public void compareToTest1() {
      
      Customer c = new Customer("Lane, Jane");
      c.changeBalance(500);
      
      Customer c2 = new Customer("Lane, Lois");
      c2.changeBalance(500);
      
      Assert.assertTrue(c.compareTo(c2) == 0);
   }
   
   /** A test for compareToTest2. **/
   @Test public void compareToTest2() {
      
      Customer c = new Customer("Lane, Jane");
      c.changeBalance(100);
      
      Customer c2 = new Customer("Lane, Lois");
      c2.changeBalance(500);
      
      Assert.assertTrue(c.compareTo(c2) < 0);
   }
   
   /** A test for compareToTest3. **/
   @Test public void compareToTest3() {
      
      Customer c = new Customer("Lane, Jane");
      c.changeBalance(1000);
      
      Customer c2 = new Customer("Lane, Lois");
      c2.changeBalance(500);
      
      Assert.assertTrue(c.compareTo(c2) > 0);
   }
  
  
}
