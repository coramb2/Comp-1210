import java.io.FileNotFoundException;

/** 
* Generates the reports for BallPlayer.
* 
* Project 10
* @author Cora Baldwin 
* @version April 13, 2022 
*/
public class BallPlayersPart2 {
   
   /**
   * Main method that creates a new BallTeam.
   * 
   * @param args - Used
   * @throws FileNotFoundException - if the file is not found
   */
   public static void main(String[] args) throws FileNotFoundException {
      
      if (args.length == 0) {
         System.out.println("File name expected as command "
            + "line argument.\nProgram ending.");
      }
      else {
         String fileName = args[0];
         BallTeam bt = new BallTeam();
         bt.readBallPlayerFile(fileName);
         System.out.print(bt.generateReport());
         System.out.println(bt.generateReportByNumber());
         System.out.println(bt.generateReportByName());
         System.out.println(bt.generateReportByEarnings());
         System.out.println(bt.generateExcludedRecordsReport());
      }
   }
}