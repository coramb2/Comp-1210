/** 
* Creates a new exception for an invalid category.
* 
* Project 11
* @author Cora Baldwin 
* @version April 21, 2022 
*/

public class InvalidCategoryException extends Exception {

   /**
   * New exception to throw for invalid categories.
   *
   * @param category - checks the category
   */
   public InvalidCategoryException(String category) {
      super("For category: " + "\"" + category + "\"");
   }
   
}