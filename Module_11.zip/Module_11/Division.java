/** 
* A class created to perform division on integers and decimal numbers.
* 
* Activity 11
* @author Cora Baldwin 
* @version April 18, 2022 
*/
public class Division {
   
   /**
   * Method to divide integers.
   * 
   * @param numerator - user inputed numerator
   * @param denominator - user inputed denominator
   * @return result - (num/denom) or 0
   */
   public static int intDivide(int numerator, int denominator) {
      try {
         return (numerator / denominator);
      }
      catch (ArithmeticException e) {
         return 0;
      }
   }
   
   /**
   * Method to divide two ints and returns a floating point decimal.
   * 
   * @param numerator - user inputed numerator
   * @param denominator - user inputed denominator
   * @return result - division of parameters
   */
   public static double decimalDivide(int numerator, int denominator) {
      if (denominator == 0) {
         throw new IllegalArgumentException("The denominator "
            + "cannot be zero.");
      }
     
      double num = numerator;
      double denom = denominator;
      return (num / denom);
      
   }
}