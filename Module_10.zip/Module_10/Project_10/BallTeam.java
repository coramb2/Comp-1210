import java.util.Scanner;
import java.util.Arrays;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;

/** 
* Creates a Ball team and creates methods to interact with the team.
* 
* Project 10
* @author Cora Baldwin 
* @version April 13, 2022 
*/
public class BallTeam {
   
   // instance variables
   private String teamName;
   private BallPlayer[] roster;
   private int playerCount;
   private String[] excludedRecords;
   private int excludedCount;
   /** Max number of players allowed in roster array. */
   public static final int MAX_PLAYERS = 24;
   /** Max number of exlcuded players allowed in excludedRecords. */
   public static final int MAX_EXCLUDED = 30;
   
   /**
   * Constructor that creates a ball team.
   * 
   */
   public BallTeam() {
      teamName = "";
      roster = new BallPlayer[24];
      playerCount = 0;
      excludedRecords = new String[30];
      excludedCount = 0;
   }
   
   /**
   * Method that returns the team name.
   * 
   * @return teamName - team name
   */
   public String getTeamName() {
      return teamName;
   }
   
   /**
   * Method that sets the team name.
   * 
   * @param teamNameIn - input team name
   */
   public void setTeamName(String teamNameIn) {
      teamName = teamNameIn;
   }
   
   /**
   * Method that returns the roster of players.
   * 
   * @return roster - all main players
   */
   public BallPlayer[] getRoster() {
      return roster;
   }
   
   /**
   * Method that sets the roster of players.
   * 
   * @param rosterIn - roster of players
   */
   public void setRoster(BallPlayer[] rosterIn) {
      roster = rosterIn;
   }
   
   /**
   * Method that returns the number of players in the roster.
   * 
   * @return playerCount - num of players
   */
   public int getPlayerCount() {
      return playerCount;
   }
   
   /**
   * Method that sets the number of players in the roster.
   * 
   * @param playerCountIn - num of players
   */
   public void setPlayerCount(int playerCountIn) {
      playerCount = playerCountIn;
   }
   
   /**
   * Method that returns the excluded players.
   * 
   * @return excludedRecords - excluded players
   */
   public String[] getExcludedRecords() {
      return excludedRecords;
   }
   
   /**
   * Method that sets the excluded players.
   * 
   * @param excludedRecordsIn - excluded players
   */
   public void setExcludedRecords(String[] excludedRecordsIn) {
      excludedRecords = excludedRecordsIn;
   }
   
   /**
   * Method that returns the number of excluded players.
   * 
   * @return excludedCount - num of excluded players
   */
   public int getExcludedCount() {
      return excludedCount;
   }
   
   /**
   * Method that sets the number of excluded players.
   * 
   * @param excludedCountIn - num of excluded players
   */
   public void setExcludedCount(int excludedCountIn) {
      excludedCount = excludedCountIn;
   }
   
   /**
   * Method that reads in the file of players.
   * 
   * @param fileName - name of file
   * @throws FileNotFoundException - for when file is not found
   */
   public void readBallPlayerFile(String fileName) 
      throws FileNotFoundException {
    
      Scanner readFile = new Scanner(new File(fileName));
      teamName = readFile.nextLine();
      
      while (readFile.hasNext()) {
         String line = readFile.nextLine();
         Scanner readLine = new Scanner(line).useDelimiter(",");
         String category = readLine.next();
         String playerNum = readLine.next();
         String playerName = readLine.next();
         String playerPosition = readLine.next();
         double baseSalary = Double.parseDouble(readLine.next());
         double bonus = Double.parseDouble(readLine.next());
         double batAvg = Double.parseDouble(readLine.next());
         
         if (playerCount < MAX_PLAYERS) {
            switch(category.charAt(0)) {
               case 'O':
                  double outfielderFieldingAvg = 
                     Double.parseDouble(readLine.next());    
                  
                  Outfielder oF = new Outfielder(playerNum, playerName,
                     playerPosition, baseSalary, bonus, batAvg, 
                     outfielderFieldingAvg);
                  roster[playerCount] = oF;
                  playerCount++;
                  break;
              
               case 'I':
                  double infielderFieldingAvg = 
                     Double.parseDouble(readLine.next());
               
                  Infielder iF = new Infielder(playerNum, playerName,
                     playerPosition, baseSalary, bonus, batAvg, 
                     infielderFieldingAvg);
                  roster[playerCount] = iF;
                  playerCount++;
                  break;
                  
               case 'P':
                  int wins = Integer.parseInt(readLine.next());
                  int losses = Integer.parseInt(readLine.next());
                  double era = Double.parseDouble(readLine.next());
               
                  Pitcher p = new Pitcher(playerNum, playerName,
                     playerPosition, baseSalary, bonus, batAvg, 
                     wins, losses, era);
                  roster[playerCount] = p;
                  playerCount++;
                  break;
                  
               case 'R':
                  wins = Integer.parseInt(readLine.next());
                  losses = Integer.parseInt(readLine.next());
                  era = Double.parseDouble(readLine.next());
                  int saves = Integer.parseInt(readLine.next());
               
                  ReliefPitcher rP = new ReliefPitcher(playerNum, playerName,
                     playerPosition, baseSalary, bonus, batAvg, wins, 
                     losses, era, saves);
                  roster[playerCount] = rP;
                  playerCount++;
                  break;
                  
               default:
                  String exPlayer = "*** invalid category *** " + line;
                  excludedRecords[excludedCount] = exPlayer;
                  excludedCount++;
                  break;
            }
         }
         else if (excludedCount < MAX_EXCLUDED) {
            String exPlayer = line;
            excludedRecords[excludedCount] = exPlayer;
            excludedCount++;
         }
      }
      readFile.close();
   }
   
   /**
   * Method that returns the roster of players.
   * 
   * @return output - summary of players
   */
   public String generateReport() {
      String output = "---------------------------------------\n" 
         + "Team Report for " + teamName
         + "\n---------------------------------------\n\n";
      
      for (int i = 0; i < playerCount; i++) {
         output += roster[i] + "\n\n";
      }
      return output;
   }
   
   /**
   * Method that returns the roster of players sorted by number.
   * 
   * @return output - sorted by number
   */
   public String generateReportByNumber() {
      DecimalFormat df = new DecimalFormat(".000");
      BallPlayer[] bp = Arrays.copyOf(roster, playerCount);
      Arrays.sort(bp);
      String output = "";
      
      for (int i = 0; i < playerCount; i++) {
         output += bp[i].getNumber() + " " + bp[i].getName()
            + " " + bp[i].getPosition() + " ";
         if (bp[i] instanceof Outfielder) {
            output += df.format(bp[i].getBattingAvg()) + "\n";
         }
         else if (bp[i] instanceof Infielder) {
            output += df.format(bp[i].getBattingAvg()) + "\n";
         }
         else if (bp[i] instanceof ReliefPitcher) {
            ReliefPitcher rp = (ReliefPitcher) bp[i];
            output += rp.getWins() + " wins, " + rp.getLosses()
               + " losses, " + rp.getSaves() + " saves, " 
               + rp.getEra() + " ERA\n";
         }
         else {
            Pitcher p = (Pitcher) bp[i];
            output += p.getWins() + " wins, " + p.getLosses()
               + " losses, " + p.getEra() + " ERA\n";
         }
      }
      return "---------------------------------------\n"
         + "Team Report for " + teamName + " (by Number)\n" 
         + "---------------------------------------\n" + output;
   }
   
   /**
   * Method that returns the roster of players sorted by name.
   * 
   * @return output - sorted by name
   */
   public String generateReportByName() {
      DecimalFormat df = new DecimalFormat(".000");
      BallPlayer[] bp = Arrays.copyOf(roster, playerCount);
      Arrays.sort(bp, new NameComparator());
      String output = "";
      
      for (int i = 0; i < playerCount; i++) {
         output += bp[i].getNumber() + " " + bp[i].getName()
            + " " + bp[i].getPosition() + " ";
         if (bp[i] instanceof Outfielder) {
            output += df.format(bp[i].getBattingAvg()) + "\n";
         }
         else if (bp[i] instanceof Infielder) {
            output += df.format(bp[i].getBattingAvg()) + "\n";
         }
         else if (bp[i] instanceof ReliefPitcher) {
            ReliefPitcher rp = (ReliefPitcher) bp[i];
            output += rp.getWins() + " wins, " + rp.getLosses()
               + " losses, " + rp.getSaves() + " saves, " 
               + rp.getEra() + " ERA\n";
         }
         else {
            Pitcher p = (Pitcher) bp[i];
            output += p.getWins() + " wins, " + p.getLosses()
               + " losses, " + p.getEra() + " ERA\n";
         }
      }
      return "---------------------------------------\n"
         + "Team Report for " + teamName + " (by Name)\n" 
         + "---------------------------------------\n" + output;
   }
   
   /**
   * Method that returns the roster of players sorted by total earnings.
   * 
   * @return output - sorted by total earnings
   */
   public String generateReportByEarnings() {
      DecimalFormat dfEarnings = new DecimalFormat("$###,###.00");
      DecimalFormat df = new DecimalFormat(".000");
      BallPlayer[] bp = Arrays.copyOf(roster, playerCount);
      Arrays.sort(bp, new EarningsComparator());
      String output = "";
      
      for (int i = 0; i < playerCount; i++) {
         output += dfEarnings.format(bp[i].totalEarnings()) 
            + " " + bp[i].getNumber()
            + " " + bp[i].getName() + " " + bp[i].getPosition() + " ";
         if (bp[i] instanceof Outfielder) {
            output += df.format(bp[i].getBattingAvg()) + "\n";
         }
         else if (bp[i] instanceof Infielder) {
            output += df.format(bp[i].getBattingAvg()) + "\n";
         }
         else if (bp[i] instanceof ReliefPitcher) {
            ReliefPitcher rp = (ReliefPitcher) bp[i];
            output += rp.getWins() + " wins, " + rp.getLosses()
               + " losses, " + rp.getSaves() + " saves, " 
               + rp.getEra() + " ERA\n";
         }
         else {
            Pitcher p = (Pitcher) bp[i];
            output += p.getWins() + " wins, " + p.getLosses()
               + " losses, " + p.getEra() + " ERA\n";
         }
      }
      return "---------------------------------------\n"
         + "Team Report for " + teamName + " (by Earnings)\n" 
         + "---------------------------------------\n" + output;
   }
   
   /**
   * Method that returns the excluded player report.
   * 
   * @return output - excluded players
   */
   public String generateExcludedRecordsReport() {
      String output = "";
      
      for (int i = 0; i < excludedCount; i++) {
         output += excludedRecords[i] + "\n";
      }
      return "---------------------------------------\n" 
         + "Excluded Records Report"
         + "\n---------------------------------------\n"
         + output;
   }
      
}