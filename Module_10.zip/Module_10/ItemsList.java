/** 
* Creates an array for items.
* 
* Activity 10 
* @author Cora Baldwin 
* @version April 11, 2022 
*/

public class ItemsList {
   
   // instance variables
   private InventoryItem[] inventory;
   private int count;
   
   /**
   * Constructor that initializes the array and sets the count to 0.
   * 
   */
   public ItemsList() {
      inventory = new InventoryItem[20];
      count = 0;
   }
   
   /**
   *Method that adds each item to the array.
   * 
   * @param itemIn - the new item
   */
   public void addItem(InventoryItem itemIn) {
      inventory[count] = itemIn;
      count++;
   }
   
   /**
   * Method that adds an electronics surcharge if an item 
   * is part of the ElectronicsItem class.
   * 
   * @param electronicsSurcharge - the surcharge
   * @return total - total of all items in the array
   */
   public double calculateTotal(double electronicsSurcharge) {
      double total = 0;
      for (int i = 0; i < count; i++) {
         if (inventory[i] instanceof ElectronicsItem) {
            total += inventory[i].calculateCost() + electronicsSurcharge;
         }
         else {
            total += inventory[i].calculateCost();
         }
      }
      return total;
   }
   
   /**
   *Method that returns all items in the array.
   * 
   * @return output - summary of all items in the array
   */
   public String toString() {
      String output = "All inventory:\n\n";
      
      for (int i = 0; i < count; i++) {
         output += inventory[i] + "\n";
      }
      return output;
   }
}