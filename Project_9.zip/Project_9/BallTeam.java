import java.util.Scanner;
import java.util.Arrays;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;

public class BallTeam {
   
   //instance variables
   private String teamName;
   private BallPlayer[] roster;
   private int playerCount;
   private String[] excludedRecords;
   private int excludedCount;
   public final static int MAX_PLAYERS = 24;
   public final static int MAX_EXCLUDED = 30;
   
   //constructor
   public BallTeam() {
      teamName = "";
      roster = new BallPlayer[24];
      playerCount = 0;
      excludedRecords = new String[30];
      excludedCount = 0;
   }
   
   //methods
   public String getTeamName() {
      return teamName;
   }
   
   public void setTeamName(String teamNameIn) {
      teamName = teamNameIn;
   }
   
   public BallPlayer[] getRoster() {
      return roster;
   }
   
   public void setRoster(BallPlayer[] rosterIn) {
      roster = rosterIn;
   }
   
   public int getPlayerCount() {
      return playerCount;
   }
   
   public void setPlayerCount(int playerCountIn) {
      playerCount = playerCountIn;
   }
   
   public String[] getExcludedRecords() {
      return excludedRecords;
   }  
   
   public void setExcludedRecords(String[] excludedRecordsIn) {
      excludedRecords = excludedRecordsIn;
   }
   
   public int getExcludedCount() {
      return excludedCount;
   }
   
   public void setExcludedCount(int excludedCountIn) {
      excludedCount = excludedCountIn;
   }
   
   public void readBallPlayerFile(String fileName) 
    throws FileNotFoundException {
    
      Scanner readFile = new Scanner(new File(fileName));
      String category = readFile.nextLine();
      
      while(readFile.hasNext()) {
         String line = readFile.nextLine();
         Scanner readLine = new Scanner(line).useDelimiter(",");
         String playerNum = readLine.next();
         String playerName = readLine.next();
         String playerPosition = readLine.next();
         double baseSalary = Double.parseDouble(readLine.next());
         double bonus = Double.parseDouble(readLine.next());
         double batAvg = Double.parseDouble(readLine.next());
         
         if(playerCount <= MAX_PLAYERS) {
            switch(category.charAt(0)) {
               case 'O':
                  double outfielderFieldingAvg = Double.parseDouble(readLine.next());    
                  
                  Outfielder oF = new Outfielder(playerNum, playerName,
                     playerPosition, baseSalary, bonus, batAvg, outfielderFieldingAvg);
                  roster[playerCount] = oF;
                  playerCount++;
                  break;
              
               case 'I':
                  double infielderFieldingAvg = Double.parseDouble(readLine.next());
               
                  Infielder iF = new Infielder(playerNum, playerName,
                     playerPosition, baseSalary, bonus, batAvg, infielderFieldingAvg);
                  roster[playerCount] = iF;
                  playerCount++;
                  break;
                  
               case 'P':
                  int wins = Integer.parseInt(readLine.next());
                  int losses = Integer.parseInt(readLine.next());
                  double era = Double.parseDouble(readLine.next());
               
                  Pitcher p = new Pitcher(playerNum, playerName,
                     playerPosition, baseSalary, bonus, batAvg, wins, losses, era);
                  roster[playerCount] = p;
                  playerCount++;
                  break;
                  
               case 'R':
                  wins = Integer.parseInt(readLine.next());
                  losses = Integer.parseInt(readLine.next());
                  era = Double.parseDouble(readLine.next());
                  int saves = Integer.parseInt(readLine.next());
               
                  ReliefPitcher rP = new ReliefPitcher(playerNum, playerName,
                     playerPosition, baseSalary, bonus, batAvg, wins, losses, era, saves);
                  roster[playerCount] = rP;
                  playerCount++;
                  break;
                  
               default:
                  String exPlayer = "*** invalid category *** " + line;
                  excludedRecords[excludedCount] = exPlayer;
                  excludedCount++;
                  break;
            }
         }
         else if(excludedCount <= MAX_EXCLUDED) {
            String exPlayer = line;
            excludedRecords[excludedCount] = exPlayer;
            excludedCount++;
         }
      }
      readFile.close();
   }
   
   public String generateReport() {
      String output = "---------------------------------------\n" 
         + "Team Report for " + getTeamName()
         + "\n---------------------------------------\n\n";
      
      for(int i = 0; i < roster.length; i++) {
         output += roster[i] + "\n\n";
      }
      return output;
   }
   
   public String generateReportByNumber() {
      
      return "by number";
   }
   
   public String generateReportByName() {
      DecimalFormat df = new DecimalFormat(".000");
      BallPlayer[] bp = Arrays.copyOf(roster, playerCount);
      Arrays.sort(bp, new NameComparator());
      String output = "";
      
      for(int i = 0; i < playerCount; i++) {
         output += bp[i].getNumber() + " " + bp[i].getName()
            + " " + bp[i].getPosition() + " ";
         if(bp[i] instanceof Outfielder) {
            output += df.format(bp[i].getBattingAvg()) + "\n";
         }
         else if(bp[i] instanceof Infielder) {
            output += df.format(bp[i].getBattingAvg()) + "\n";
         }
         else if(bp[i] instanceof Pitcher) {
            Pitcher p = (Pitcher) bp[i];
            output += p.getWins() +  "wins " + p.getLosses()
               + " losses " + + p.getEra() + " ERA\n";
         }
         else {
            ReliefPitcher rp = (ReliefPitcher) bp[i];
            output += rp.getWins() + " wins " + rp.getLosses()
               + " losses " + rp.getEra() + " ERA\n";
         }
      }
      return getTeamName() + "(by Name)\n" + output;
   }
   
   public String generateReportByEarnings() {
      return "by earnings";
   }
   
   public String generateExcludedRecordsReport() {
      return "excluded records";
   }
}