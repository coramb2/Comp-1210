import org.junit.Assert;
//import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/** 
* Test for Pitcher.
* 
* Project 9 
* @author Cora Baldwin 
* @version April 8, 2022 
*/
public class PitcherTest {


   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before public void setUp() {
   }

   /** Test for getWins. **/
   @Test public void getWinsTest() {
      Pitcher p3 = new Pitcher("43", "Jo Williams", "RHP", 150000, 
                              3.50, .125, 22, 4, 2.85); 
      Assert.assertEquals("getWinsTest", 22, p3.getWins());
   }
   
   /** Test for setWins. **/
   @Test public void setWinsTest() {
      Pitcher p3 = new Pitcher("43", "Jo Williams", "RHP", 150000, 
                              3.50, .125, 22, 4, 2.85); 
      p3.setWins(23);
      Assert.assertEquals("setWinsTest", 23, p3.getWins());
   }
   
   /** Test for getLosses. **/
   @Test public void getLossesTest() {
      Pitcher p3 = new Pitcher("43", "Jo Williams", "RHP", 150000, 
                              3.50, .125, 22, 4, 2.85); 
      Assert.assertEquals("getLossesTest", 4, p3.getLosses());
   }
   
   /** Test for setLosses. **/
   @Test public void setLossesTest() {
      Pitcher p3 = new Pitcher("43", "Jo Williams", "RHP", 150000, 
                              3.50, .125, 22, 4, 2.85); 
      p3.setLosses(4);
      Assert.assertEquals("setLossesTest", 4, p3.getLosses());
   }
   
   /** Test for getEra. **/
   @Test public void getEraTest() {
      Pitcher p3 = new Pitcher("43", "Jo Williams", "RHP", 150000, 
                              3.50, .125, 22, 4, 2.85); 
      Assert.assertEquals("getEraTest", 2.85, p3.getEra(), 0.001);
   }
   
   /** Test for setEra. **/
   @Test public void setEraTest() {
      Pitcher p3 = new Pitcher("43", "Jo Williams", "RHP", 150000, 
                              3.50, .125, 22, 4, 2.85); 
      p3.setEra(3.85);
      Assert.assertEquals("setEraTest", 3.85, p3.getEra(), 0.001);
   }
   
   /** Test for totalEarnings. **/
   @Test public void totalEarningsTest() {
      Pitcher p3 = new Pitcher("43", "Jo Williams", "RHP", 150000, 
                              3.50, .125, 22, 4, 2.85); 
      Assert.assertEquals("totalEarningsTest", 248181.8182, 
            p3.totalEarnings(), 0.0001);
   }
   
   /** Test for stats. **/
   @Test public void statsTest() {
      Pitcher p3 = new Pitcher("43", "Jo Williams", "RHP", 150000, 
                              3.50, .125, 22, 4, 2.85); 
      Assert.assertEquals("statsTest", true,
            p3.stats().contains("22 wins, 4 losses"));
   }
   
   /** Test for toString. **/
   @Test public void toStringTest() {
      Pitcher p3 = new Pitcher("43", "Jo Williams", "RHP", 150000, 
                              3.50, .125, 22, 4, 2.85); 
      Assert.assertEquals("toStringTest", true,
            p3.toString().contains("43 Jo Williams (RHP)"));
   }
}
