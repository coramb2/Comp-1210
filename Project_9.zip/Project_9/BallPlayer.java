import java.text.DecimalFormat;
/** 
* Creates a ball player and stores data about the player.
* 
* Project 9 
* @author Cora Baldwin 
* @version April 8, 2022 
*/
public abstract class BallPlayer implements Comparable<BallPlayer> {

// instance variables
   protected String playerNum;
   protected String playerName;
   protected String playerPosition;
   protected double baseSalary;
   protected double bonus;
   protected double batAvg;
   protected static int count = 0;

/**
   * Constructor that takes the characteristics of a ballplayer.
   * 
   * @param playerNumIn - Takes a number
   * @param playerNameIn - Takes the player name
   * @param playerPositionIn - player's position
   * @param baseSalaryIn - base salary
   * @param bonusIn - bonus
   * @param batAvgIn - batting avg
   */
   public BallPlayer(String playerNumIn, String playerNameIn, 
      String playerPositionIn, double baseSalaryIn, 
      double bonusIn, double batAvgIn) {
      
      playerNum = playerNumIn;
      playerName = playerNameIn;
      playerPosition = playerPositionIn;
      baseSalary = baseSalaryIn;
      bonus = bonusIn;
      batAvg = batAvgIn;
      count++;
   }
   
   /**
   * Method that returns the player's number.
   * 
   * @return playerNum - player number
   */
   public String getNumber() { //checked
      return playerNum;
   }
   
   /**
   * Method that sets the player's number.
   * 
   * @param playerNumIn - player number
   */
   public void setNumber(String playerNumIn) { //checked
      playerNum = playerNumIn;
   }
   
   /**
   * Method that returns the player's name.
   * 
   * @return playerName - player name
   */
   public String getName() { //checked
      return playerName;
   }
   
   /**
   * Method that sets the player's name.
   * 
   * @param playerNameIn - player name
   */
   public void setName(String playerNameIn) { //checked
      playerName = playerNameIn;
   }
   
   /**
   * Method that returns the player's position.
   * 
   * @return playerPosition - player position
   */
   public String getPosition() { //checked
      return playerPosition;
   }
   
   /**
   * Method that sets the player's position.
   * 
   * @param playerPositionIn - player position
   */
   public void setPosition(String playerPositionIn) { //checked
      playerPosition = playerPositionIn;
   }
   
   /**
   * Method that returns the player's base salary.
   * 
   * @return baseSalary - player base salary
   */
   public double getBaseSalary() { //checked
      return baseSalary;
   }
   
   /**
   * Method that sets the player's base salary.
   * 
   * @param baseSalaryIn - player base salary
   */
   public void setBaseSalary(double baseSalaryIn) { //checked
      baseSalary = baseSalaryIn;
   }
   
   /**
   * Method that returns the player's bonus.
   * 
   * @return bonus - player bonus
   */
   public double getBonusAdjustmentFactor() { //checked
      return bonus;
   }
   
   /**
   * Method that sets the player's bonus.
   * 
   * @param bonusIn - player bonus
   */
   public void setBonusAdjustmentFactor(double bonusIn) { //checked
      bonus = bonusIn;
   }
   
   /**
   * Method that returns the player's batting average.
   * 
   * @return batAvg - player batting avg
   */
   public double getBattingAvg() { //checked
      return batAvg;
   }
   
   /**
   * Method that sets the player's batting average.
   * 
   * @param batAvgIn - player batting avg
   */
   public void setBattingAvg(double batAvgIn) { //checked
      batAvg = batAvgIn;
   }
   
   /**
   * Method that returns the number of BallPlayer objects created.
   * 
   * @return count - num of objects
   */
   public static int getCount() { //checked
      return count;
   }
   
   /**
   * Method that resets the number of objects.
   * 
   */
   public static void resetCount() { //checked
      count = 0;
   }
   
   /**
   * Method that returns the player's stats.
   * 
   * @return batAvg - player batting avg
   */
   public String stats() { //checked
      DecimalFormat df = new DecimalFormat(".000");
      return df.format(batAvg);
   }
   
   /**
   * Method that returns the player's summary.
   * 
   * @return output - player summary
   */
   public String toString() { //checked
      DecimalFormat df = new DecimalFormat("$##0,000.00");
      String output = playerNum + " " + playerName 
         + " (" + playerPosition + ") " + stats() 
         + "\nBase Salary: " + df.format(baseSalary) 
         + " Bonus Adjustment Factor: " + bonus 
         + "\nTotal Earnings: " + df.format(totalEarnings()) 
         + " (" + getClass() + ")";
      return output;
   }
   
   /**
   * Abstract method that returns the player's total earnings.
   * 
   * @return total - total earnings
   */
   public abstract double totalEarnings();
   
   public int compareTo(BallPlayer playerIn) {
      return playerIn.getNumber().compareTo(this.getNumber());
   }
      
}