import java.util.ArrayList;
import java.text.DecimalFormat;

/** 
* Stores the name of the list of trapezohedrons and 
* creates an ArrayList of objects.
* 
* Project 5 
* @author Cora Baldwin 
* @version February 17, 2022 
*/
public class TrapezohedronList {

   // instance variables
   private String name;
   private ArrayList<Trapezohedron> objects = new ArrayList<Trapezohedron>();
   
   /** 
   * Constructor that sets variables to the parameters.
   * @param nameIn Name of the new Trapezohedrons
   * @param objectsIn Creates object list
   */
   public TrapezohedronList(String nameIn, ArrayList<Trapezohedron> objectsIn) {
      
      name = nameIn;
      objects = objectsIn;
   }
   
   // methods
   /** 
   * Gets the name of the trapezohedron list.
   * @return name Name of the new Trapezohedron
   */
   public String getName() {
      
      return name;
   }
   
   /** 
   * The size of the ArrayList.
   * @return objects.size() Size of the ArrayList
   */
   public int numberOfTrapezohedrons() {
      
      return objects.size();
   }
   
   /** 
   * Calculates the total surface area of all objects.
   * @return totalSA The total surface area
   */
   public double totalSurfaceArea() {
      
      int count = numberOfTrapezohedrons();
      double totalSA = 0.0;
      int index = 0;
      
      if (count > 0) {
         
         while (index < numberOfTrapezohedrons()) {
            
            totalSA += objects.get(index).surfaceArea();
            index++;
         }
         
         return totalSA;
      }
      else {
         
         return 0;
      }
   }
   
   /** 
   * Calculates the total volume of all objects.
   * @return totalV the total volume
   */
   public double totalVolume() {
      
      int count = numberOfTrapezohedrons();
      double totalV = 0.0;
      int index = 0;
      
      if (count > 0) {
         
         while (index < numberOfTrapezohedrons()) {
         
            totalV += objects.get(index).volume();
            
            index++;
         }
         
         return totalV;
      }
      else {
         
         return 0;
      }
   }
   
   /** 
   * Calculates the average surfaace area of objects.
   * @return avgSA Average surface area
   */
   public double averageSurfaceArea() {
      
      int count = numberOfTrapezohedrons();
      double avgSA = totalSurfaceArea() / count;
      
      if (count > 0) {
        
         return avgSA;
      }
      else {
         
         return 0;
      }
   }
   
   /** 
   * Calculates the average volume of objects.
   * @return avgVolume Average volume
   */
   public double averageVolume() {
      
      int count = numberOfTrapezohedrons();
      double avgVolume = totalVolume() / count;
      
      if (count > 0) {
         
         return avgVolume;
      }
      else {
         
         return 0;
      }
   }
   
   /** 
   * Creates an output for the name and info of the objects for each object.
   * @return output Info for objects
   */
   public String toString() {
   
      int index = 0;
      
      String output = getName() + "\n";
      output += "\n";
      
      while (index < numberOfTrapezohedrons()) {
      
         output += objects.get(index).toString() + "\n";
         
         index++;
      }
      
      return output;
   }
   
   /** 
   * Creates a summary of the # of objects, total SA,
   * total vol, avg SA and avg volume.
   * @return output Summary of data
   */
   public String summaryInfo() {
   
      DecimalFormat df = new DecimalFormat("#,##0.0##");
      String output = "";
      
      if (numberOfTrapezohedrons() > 0) {
         output = "----- Summary for " + getName() + " -----\n";
      }
      else {
         output = "----- Summary for Trapezohedron Empty Test List -----\n";
      }
      output += "Number of Trapezohedrons: " + numberOfTrapezohedrons() + "\n";
      output += "Total Surface Area: " + df.format(totalSurfaceArea()) 
         + " square units\n";
      output += "Total Volume: " + df.format(totalVolume()) + " cubic units\n";
      output += "Average Surface Area: " + df.format(averageSurfaceArea()) 
         + " square units\n";
      output += "Average Volume: " + df.format(averageVolume()) 
         + " cubic units";
      
      return output;
   }
}