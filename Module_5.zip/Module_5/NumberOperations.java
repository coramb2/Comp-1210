/**
* Class which will hold an integer value and provide methods to 
* perform various operations on that value.
*
* Activity 5
* @author Cora Baldwin
* @version Feb 15, 2022
*/

public class NumberOperations {
// variable
   private int number;
   
   
  /**
   * Constructor that sets the taken parameter to the private variable number.
   * 
   * @param numberIn - Takes user input for an int value
   */
   public NumberOperations(int numberIn) {
   // setting number to parameter
      number = numberIn;
   }
   
  /**
   * Returns the value of number.
   * 
   * @return number - Returns the number given by the user
   */
   public int getValue() {
   // returns number
      return number; 
   }
   
  /**
   * Creates the string output for all odd numbers under the given number.
   * 
   * @return output - List of odd numbers
   */
   public String oddsUnder() {
   // initializes local variables
      String output = "";
      int i = 0;
      // tests for odd numbers up until number
      while (i < number) {
         if (i % 2 != 0) {
            output += i + "\t";
         }
         i++;
      }
      
      return output; 
   }
   
  /**
   * Creates the string output for numbers that are a power of two 
   * under the given number.
   * 
   * @return ouput - List of powers of two
   */
   public String powersTwoUnder() {
   // initializes local variables
      String output = "";
      int powers = 1;
      // tests for powers of 2 until number
      while (powers < number) {
         output += powers + "\t";
         powers = powers * 2;
      }
      
      return output; 
   }
   
  /**
   * Compares parameter to given number.
   * 
   * @param compareNumber - Number to compare to given input
   * @return 1 - -1 - 0 - Depends on comparison
   */
   public int isGreater(int compareNumber) {
   // tests the value of number against compareNumber
      if (number > compareNumber) {
         return 1;
      }
      else if (number < compareNumber) {
         return -1;
      }
      else {
         return 0;
      }
   }
   
  /**
   * Returns a number.
   * 
   * @return number - Prints the number
   */
   public String toString() {
   // returns number
      return number + ""; 
   }
}