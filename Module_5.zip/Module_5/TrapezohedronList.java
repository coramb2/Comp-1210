import java.util.ArrayList;
import java.text.DecimalFormat;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * Program that takes Trapezohedron objects into an array list
 * and outputs collective array information.
 *
 * @author Dean Little - COMP 1210 - 001
 * @version 2/18/22
 */
public class TrapezohedronList {
   
   //Instance Variables
   private String trapName = "";
   private ArrayList<Trapezohedron> trapList = new ArrayList<Trapezohedron>(); 
   
   //Constructor
   /**
    * Sets up input for array and array name.
    * @param trapNameIn name or trapezohedron
    * @param trapListIn variable for trap arrays 
    */
   public TrapezohedronList(String trapNameIn, 
      ArrayList<Trapezohedron> trapListIn) {
      trapName = trapNameIn;
      trapList = trapListIn;
   }
   //Methods
   /**
    * Gets trapezohedron name.
    * @return trapName name of trapezohedron
    */
   public String getName() {
      return trapName;
   }
   /**
    * Gets number of trapezohedrons in array.
    * @return number representing presence of shapes
    */
   public int numberOfTrapezohedrons() {
      if (trapList.size() == 0) {
         return 0;   
      }
      else {
         return trapList.size();
      }
     
   }
   /**
    * Adds surface area from each trapezohedron.
    * @return total
    */
   public double totalSurfaceArea() {
      double totalS = 0;
      int indexS = 0;
      while (indexS < trapList.size()) {
         totalS += trapList.get(indexS).surfaceArea();
         indexS++;
      }
      return totalS;
   }
   /**
    * Adds volume from each trapezohedron.
    * @return total
    */
   public double totalVolume() {
      double totalV = 0;
      int indexV = 0;
      while (indexV < trapList.size()) {
         totalV += trapList.get(indexV).volume();
         indexV++;
      }
      return totalV;
   }
   /**
    * Averages surface area from all trapezohedrons.
    * @return averaged surface area
    */
   public double averageSurfaceArea() {
      if (trapList.size() == 0) {
         return 0.0;
      }
      else {
         return totalSurfaceArea() / trapList.size();
      }
   }
   /**
    * Averages volume from all trapezohedron.
    * @return averaged volume
    */
   public double averageVolume() {
      if (trapList.size() == 0) {
         return 0.0;
      }
      else {
         return totalVolume() / trapList.size();
      }
      
   }
   /**
    * Converts data to output string.
    * @return output string output
    */
   public String toString() {
      int index = 0;
      String output = "";
      System.out.println("\n" + trapName);
      
      if (trapList.size() == 0) {
         output = "";
      }
      else {
         while (index < trapList.size()) {
            output += trapList.get(index) + "\n";
            index++;
         }
      }
      return output;
      
   }
   /**
    * Summarizes Trapezohedron info in a string.
    * @return output summarized info
    */
   public String summaryInfo() {
      DecimalFormat df = new DecimalFormat("#,##0.0##");
      String output = "----- Summary for " + trapName + " -----";
      output += "\nNumber of Trapezohedrons: " 
         + df.format(numberOfTrapezohedrons());
      output += "\nTotal Surface Area: " 
         + df.format(totalSurfaceArea()) + " square units";
      output += "\nTotal Volume: " + df.format(totalVolume()) 
         + " cubic units";
      output += "\nAverage Surface Area: " 
         + df.format(averageSurfaceArea()) + " square units";
      output += "\nAverage Volume: " + df.format(averageVolume()) 
         + " cubic units";
      return output;
   }
   /**
    * Gets list of trapezohedrons.
    * @return trapList list of traps
    */
   public ArrayList<Trapezohedron> getList() {
      return trapList;
   }
   /**
    * Reads given file from user and puts data into arraylist.
    * @param fileName name of file to read
    * @return listTrapList
    * @throws FileNotFoundException checks for absent file
    */
   public TrapezohedronList readFile(String fileName) 
      throws FileNotFoundException {
      Scanner fileRead = new Scanner(new File(fileName));
      
      String trapezohedronListName = "";
      if (fileRead.hasNext()) {
         trapezohedronListName = fileRead.nextLine();
      }
      while (fileRead.hasNext()) {
         String label = fileRead.nextLine();
         String color = fileRead.nextLine(); 
         double length = Double.parseDouble(fileRead.nextLine());
         
         Trapezohedron t = new Trapezohedron(label, color, length);
         trapList.add(t);
      }
      fileRead.close();
      
      TrapezohedronList listTrapList = new 
         TrapezohedronList(trapezohedronListName, trapList);
      return listTrapList;
   }
   /**
    * Adds a trapezohedron to the ArrayList.
    * @param labelIn label in
    * @param colorIn color in
    * @param shortEdgeIn length in
    */
   public void addTrapezohedron(String labelIn, String colorIn, 
      double shortEdgeIn) {
      Trapezohedron t = new Trapezohedron(labelIn, colorIn, shortEdgeIn);
      trapList.add(t);
   }
   /**
    * Searches for a trapezohedron in the arraylist via label.
    * @param labelIn label in
    * @return output
    */
   public Trapezohedron findTrapezohedron(String labelIn) {
      String label = "";
      Trapezohedron output = null;
      int i = 0;
      
      for (Trapezohedron trap : trapList) {
         label = trap.getLabel();
         if (label.equalsIgnoreCase(labelIn)) {
            output = trapList.get(i);
            break;
         }
         else if (i < trapList.size()) {
            i++;
         }
         else {
            break;
         }
         
      }
      return output;
   }
   /**
    * Deletes a trapezohedron from the arraylist.
    * @param labelIn takes label in
    * @return output
    */
   public Trapezohedron deleteTrapezohedron(String labelIn) {
      String label = "";
      Trapezohedron output = null;
      int i = 0;
      
      for (Trapezohedron trap : trapList) {
         label = trap.getLabel();
         if (label.equalsIgnoreCase(labelIn)) {
            output = trap;
            trapList.remove(i);
            break;
         }
         else if (i < trapList.size()) {
            i++;
         }
         else {
            break;
         }
      }
      return output;
   }
   /**
    * Edits one of the existing trapezohedrons wihtin the arraylist.
    * @param labelIn label in
    * @param colorIn color in
    * @param shortEdgeIn length in
    * @return output
    */
   public boolean editTrapezohedron(String labelIn, 
      String colorIn, double shortEdgeIn) {
      String label = "";
      boolean output = false;
      int i = 0;
      
      for (Trapezohedron trap : trapList) {
         label = trap.getLabel();
         if (label.equalsIgnoreCase(labelIn)) {
            trap.setColor(colorIn);
            trap.setShortEdge(shortEdgeIn);
            output = true;
            break;
         }
         else if (i < trapList.size()) {
            i++;
         }
         else {
            break;
         }
      }
      return output;
   }
}