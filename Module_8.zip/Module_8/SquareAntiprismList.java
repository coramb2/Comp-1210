import java.text.DecimalFormat;

/** 
* Creates a list of SquareAntiprisms and methods.
* 
* Project 8
* @author Cora Baldwin 
* @version March 31, 2022 
*/
public class SquareAntiprismList {

   // instance variables
   private String name = "";
   private SquareAntiprism[] objects;
   private int numOfObjects = 0;
   
   /**
   * Constructor that creates a new square antiprism array.
   * 
   * @param nameIn - name of array
   * @param objectsIn - takes a new object
   * @param numOfObjectsIn - the number of new objects
   */
   public SquareAntiprismList(String nameIn, 
      SquareAntiprism[] objectsIn, int numOfObjectsIn) {
         
      name = nameIn;
      objects = objectsIn;
      numOfObjects = numOfObjectsIn;
   }
   
   /**
   * Method to return the name.
   * 
   * @return name - name of array
   */
   public String getName() { //checked
      return name;
   }
   
   /**
   * Method to return the number of objects in the array.
   * 
   * @return numOfObjects - # of objects in array
   */
   public int numberOfSquareAntiprisms() { //checked
      return numOfObjects;
   }
   
   /**
   * Method to calculate the total surface area in the array.
   * 
   * @return total - total SA
   */
   public double totalSurfaceArea() { //checked
      double total = 0;
      for (int i = 0; i < numOfObjects; i++) {
         total += objects[i].surfaceArea();
      }
      
      return total;
   }
   
   /**
   * Method to calculate the total volume of the array.
   * 
   * @return total - total volume
   */
   public double totalVolume() { //checked
      double total = 0;
      for (int i = 0; i < numOfObjects; i++) {
         total += objects[i].volume();
      }
      
      return total;
   }
   
   /**
   * Method to calculate the average surface area of the array.
   * 
   * @return average - avg SA
   */
   public double averageSurfaceArea() { //checked
      double average = 0;
      for (int i = 0; i < numOfObjects; i++) {
         average += objects[i].surfaceArea() / numOfObjects;
      }
      
      return average;
   }
   
   /**
   * Method to calculate the average volume of the array.
   * 
   * @return average - avg volume
   */
   public double averageVolume() { //checked
      double average = 0;
      for (int i = 0; i < numOfObjects; i++) {
         average += objects[i].volume() / numOfObjects;
      }
      
      return average;
   }
   
   /**
   * Method to return a summary of the array.
   * 
   * @return output - summary
   */
   public String toString() { //checked
      DecimalFormat df = new DecimalFormat("#,##0.0##");
      String output = "----- Summary for " + getName() + " -----\n"
         + "Number of SquareAntiprisms: " + numOfObjects + "\n"
         + "Total Surface Area: " + df.format(totalSurfaceArea()) 
         + " square units\nTotal Volume: " + df.format(totalVolume()) 
         + " cubic units\nAverage Surface Area: " 
         + df.format(averageSurfaceArea()) + " square units\nAverage Volume: " 
         + df.format(averageVolume()) + " cubic units";
         
      return output;
   }
   
   /**
   * Method to return the array.
   * 
   * @return objects - array
   */
   public SquareAntiprism[] getList() { //checked
      return objects;
   }
   
   /**
   * Method to add a new Square Antiprism to the array.
   * 
   * @param labelIn - user input of label
   * @param edgeIn - input of edge length
   */
   public void addSquareAntiprism(String labelIn, double edgeIn) { //checked
      SquareAntiprism s = new SquareAntiprism(labelIn, edgeIn);
      objects[numOfObjects] = s;
      numOfObjects++;
   }
   
   /**
   * Method to find an object in the array.
   * 
   * @param labelIn - user input of label
   * @return result - the matching object
   */
   public SquareAntiprism findSquareAntiprism(String labelIn) { //checked
      SquareAntiprism result = null;
      for (int i = 0; i < numOfObjects; i++) {
         if (objects[i].getLabel().equalsIgnoreCase(labelIn)) {
            result = objects[i];
         }
      }
      
      return result;
   }
   
   /**
   * Method to delete an object from the array.
   * 
   * @param labelIn - user input of label
   * @return result - deleted object
   */
   public SquareAntiprism deleteSquareAntiprism(String labelIn) { //checked
      SquareAntiprism result = null;
      for (int i = 0; i < numOfObjects; i++) { 
         if (objects[i].getLabel().equalsIgnoreCase(labelIn)) { 
            result = objects[i];
            for (int c = i; c < numOfObjects - 1; c++) {
               objects[c] = objects[c + 1];
            }
            objects[numOfObjects - 1] = null;
            numOfObjects--;
            break;
         }
      }
      
      return result;
   }
   
   /**
   * Method to edit an object in the array.
   * 
   * @param labelIn - user input of label
   * @param edgeIn - input of new edge
   * @return result - updated object
   */
   public boolean editSquareAntiprism(String labelIn, double edgeIn) { //checked
      boolean result = false;
      for (int i = 0; i < numOfObjects; i++) { 
         if (objects[i].getLabel().equalsIgnoreCase(labelIn)) {
               
            objects[i].setEdge(edgeIn);
            result = true;
         }
      }
      
      return result;
   }
   
   /**
   * Method to find the object with the largest volume.
   * 
   * @return temp - object w/ largest volume
   */
   public SquareAntiprism findSquareAntiprismWithLargestVolume() { //checked
      if (numOfObjects == 0) {
         return null;
      }
      else {
         double largest = objects[0].volume();
         SquareAntiprism temp = new SquareAntiprism(null, 0);
         temp = objects[0];
         for (int i = 0; i < numOfObjects; i++) {
            if (largest < objects[i].volume()) {
               largest = objects[i].volume();
               temp = objects[i];
            }
         }
         return temp;
      }
   }
}