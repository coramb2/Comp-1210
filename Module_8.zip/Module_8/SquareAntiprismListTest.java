import org.junit.Assert;
//import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/** 
* JUnit test for SquareAntiprismList.
* 
* Project 8 
* @author Cora Baldwin 
* @version March 31, 2022 
*/
public class SquareAntiprismListTest {


   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before public void setUp() {
   }


   /**
   * Test for getName method.
   */
   @Test public void getNameTest() {
      SquareAntiprism[] objArray = new SquareAntiprism[3];
      objArray[0] = new SquareAntiprism("Ex1", 1);
      objArray[0] = new SquareAntiprism("Ex2", 2);
      objArray[0] = new SquareAntiprism("Ex3", 3);
      
      SquareAntiprismList objList = 
         new SquareAntiprismList("Test", objArray, 3);
      
      Assert.assertEquals("getNameTest", "Test", objList.getName());
   }
   
   /**
   * Test for numberOfSquareAntiprisms method.
   */
   @Test public void numberOfSquareAntiprismsTest() {
      SquareAntiprism[] objArray = new SquareAntiprism[3];
      objArray[0] = new SquareAntiprism("Ex1", 1);
      objArray[0] = new SquareAntiprism("Ex2", 2);
      objArray[0] = new SquareAntiprism("Ex3", 3);
      
      SquareAntiprismList objList = 
         new SquareAntiprismList("Test", objArray, 3);
      
      Assert.assertEquals("numOfSATest", 3, objList.numberOfSquareAntiprisms());
   }
   
   /**
   * Test for totalSurfaceArea method.
   */
   @Test public void totalSurfaceAreaTest() {
      SquareAntiprism[] objArray = new SquareAntiprism[3];
      objArray[0] = new SquareAntiprism("Ex1", 1);
      objArray[1] = new SquareAntiprism("Ex2", 2);
      objArray[2] = new SquareAntiprism("Ex3", 3);
      
      SquareAntiprismList objList = 
         new SquareAntiprismList("Test", objArray, 3);
      
      Assert.assertEquals("totalSurfaceAreaTest", 232.19078, 
         objList.totalSurfaceArea(), 0.0001);
   }
   
   /**
   * Test for totalVolumeTest method.
   */
   @Test public void totalVolumeTest() {
      SquareAntiprism[] objArray = new SquareAntiprism[3];
      objArray[0] = new SquareAntiprism("Ex1", 1);
      objArray[1] = new SquareAntiprism("Ex2", 2);
      objArray[2] = new SquareAntiprism("Ex3", 3);
      
      SquareAntiprismList objList = 
         new SquareAntiprismList("Test", objArray, 3);
      
      Assert.assertEquals("totalVolumeTest", 153.64643, 
         objList.totalVolume(), 0.0001);
   }
   
   /**
   * Test for averageSurfaceArea method.
   */
   @Test public void averageSurfaceAreaTest() {
      SquareAntiprism[] objArray = new SquareAntiprism[3];
      objArray[0] = new SquareAntiprism("Ex1", 1);
      objArray[1] = new SquareAntiprism("Ex2", 2);
      objArray[2] = new SquareAntiprism("Ex3", 3);
      
      SquareAntiprismList objList = 
         new SquareAntiprismList("Test", objArray, 3);
      
      Assert.assertEquals("averageSurfaceAreaTest", 77.39692, 
         objList.averageSurfaceArea(), 0.0001);
   }
   
   /**
   * Test for averageVolume method.
   */
   @Test public void averageVolumeTest() {
      SquareAntiprism[] objArray = new SquareAntiprism[3];
      objArray[0] = new SquareAntiprism("Ex1", 1);
      objArray[1] = new SquareAntiprism("Ex2", 2);
      objArray[2] = new SquareAntiprism("Ex3", 3);
      
      SquareAntiprismList objList = 
         new SquareAntiprismList("Test", objArray, 3);
      
      Assert.assertEquals("averageVolumeTest", 51.21547, 
         objList.averageVolume(), 0.0001);
   }
   
   /**
   * Test for toString method.
   */
   @Test public void toStringTest() {
      SquareAntiprism[] objArray = new SquareAntiprism[3];
      objArray[0] = new SquareAntiprism("Ex1", 1);
      objArray[1] = new SquareAntiprism("Ex2", 2);
      objArray[2] = new SquareAntiprism("Ex3", 3);
      
      SquareAntiprismList objList = 
         new SquareAntiprismList("Test", objArray, 3);
      
      Assert.assertEquals("toStringTest", true, 
         objList.toString().contains("Summary for Test"));
   }
   
   /**
   * Test for getList method.
   */
   @Test public void getListTest() {
      SquareAntiprism[] objArray = new SquareAntiprism[3];
      objArray[0] = new SquareAntiprism("Ex1", 1);
      objArray[1] = new SquareAntiprism("Ex2", 2);
      objArray[2] = new SquareAntiprism("Ex3", 3);
      
      SquareAntiprismList objList = 
         new SquareAntiprismList("Test", objArray, 3);
      
      Assert.assertArrayEquals("getListTest", objArray, objList.getList());
   }
   
   /**
   * Test for addSquareAntiprism method.
   */
   @Test public void addSquareAntiprismTest() {
      SquareAntiprism[] objArray = new SquareAntiprism[4];
      objArray[0] = new SquareAntiprism("Ex1", 1);
      objArray[1] = new SquareAntiprism("Ex2", 2);
      objArray[2] = new SquareAntiprism("Ex3", 3);
      
      SquareAntiprismList objList = 
         new SquareAntiprismList("Test", objArray, 3);
      SquareAntiprism addObj = new SquareAntiprism("Add", 4);
      
      objList.addSquareAntiprism("Add", 4);
      SquareAntiprism[] objArray2 = objList.getList();
      
      Assert.assertEquals("addSquareAntiprism", addObj, objArray[3]);
      
   }
   
   /**
   * Test for findSquareAntiprism method.
   */
   @Test public void findSquareAntiprismTest() {
      SquareAntiprism[] objArray = new SquareAntiprism[3];
      objArray[0] = new SquareAntiprism("Ex1", 1);
      objArray[1] = new SquareAntiprism("Ex2", 2);
      objArray[2] = new SquareAntiprism("Ex3", 3);
      
      SquareAntiprismList objList = 
         new SquareAntiprismList("Test", objArray, 3);
      
      Assert.assertEquals("findSquareAntiprismTest fail", null, 
         objList.findSquareAntiprism("Ex"));
      Assert.assertEquals("findSquareAntiprismTest", objArray[0],
         objList.findSquareAntiprism("Ex1"));
   }
   
   /**
   * Test for deleteSquareAntiprism method.
   */
   @Test public void deleteSquareAntiprismTest() {
      SquareAntiprism[] objArray = new SquareAntiprism[3];
      objArray[0] = new SquareAntiprism("Ex1", 1);
      objArray[1] = new SquareAntiprism("Ex2", 2);
      objArray[2] = new SquareAntiprism("Ex3", 3);
      
      SquareAntiprismList objList = 
         new SquareAntiprismList("Test", objArray, 3);
      
      Assert.assertEquals("deleteSquareAntiprismTest fail", null,
         objList.deleteSquareAntiprism("Ex"));
      Assert.assertEquals("deleteSquareAntiprismTest", objArray[0],
         objList.deleteSquareAntiprism("Ex1"));
   }
   
   /**
   * Test for editSquareAntiprism method.
   */
   @Test public void editSquareAntiprismTest() {
      SquareAntiprism[] objArray = new SquareAntiprism[3];
      objArray[0] = new SquareAntiprism("Ex1", 1);
      objArray[1] = new SquareAntiprism("Ex2", 2);
      objArray[2] = new SquareAntiprism("Ex3", 3);
      
      SquareAntiprismList objList = 
         new SquareAntiprismList("Test", objArray, 3);
      
      Assert.assertEquals("editSquareAntiprismTest fail", false, 
         objList.editSquareAntiprism("Ex", 1));
      Assert.assertEquals("editSquareAntiprismTest", true,
         objList.editSquareAntiprism("Ex1", 4));
   }
   
   /**
   * Test for findSquareAntiprismWithLargestVolume method.
   */
   @Test public void findSquareAntiprismWithLargestVolumeTest() {
      SquareAntiprism[] objArray2 = new SquareAntiprism[0];
      SquareAntiprismList objList2 = 
         new SquareAntiprismList("Test2", objArray2, 0);
      
      Assert.assertEquals("largestVolumeTest fail", null, 
         objList2.findSquareAntiprismWithLargestVolume());
   
      SquareAntiprism[] objArray = new SquareAntiprism[3];
      objArray[0] = new SquareAntiprism("Ex1", 1);
      objArray[1] = new SquareAntiprism("Ex2", 2);
      objArray[2] = new SquareAntiprism("Ex3", 3);
      
      SquareAntiprismList objList = 
         new SquareAntiprismList("Test", objArray, 3);
      
      Assert.assertEquals("largestVolumeTest", objArray[2],
         objList.findSquareAntiprismWithLargestVolume());
      
   }
}
