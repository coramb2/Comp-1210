/** 
* Creates an array of scores with methods to interact.
* 
* Activity 8 
* @author Cora Baldwin 
* @version March 27, 2022 
*/
public class Scores {

   // instance variables
   private int[] numbers;
   
   /**
   * Constructor that creates a new array of numbers.
   * 
   * @param numbersIn - array
   */
   public Scores(int[] numbersIn) {
      numbers = numbersIn;
   }
   
   /**
   * Method to find the even numbers in the array.
   * 
   * @return evens - even nums in array
   */
   public int[] findEvens() {
      int numberEvens = 0;
      
      for (int i = 0; i < numbers.length; i++) {
         if (numbers[i] % 2 == 0) {
            numberEvens++;
         }
      }
      
      int[] evens = new int[numberEvens];
      int count = 0;
      
      for (int i = 0; i < numbers.length; i++) {
         if (numbers[i] % 2 == 0) {
            evens[count] = numbers[i];
            count++;
         }
      }
      
      return evens;
   }
   
   /**
   * Method to find the odd numbers in the array.
   * 
   * @return odds - odd nums in array
   */
   public int[] findOdds() {
      int numberOdds = 0;
      
      for (int i = 0; i < numbers.length; i++) {
         if (numbers[i] % 2 == 1) {
            numberOdds++;
         }
      }
      
      int[] odds = new int[numberOdds];
      int count = 0;
      
      for (int i = 0; i < numbers.length; i++) {
         if (numbers[i] % 2 == 1) {
            odds[count] = numbers[i];
            count++;
         }
      }
      
      return odds;
   }
   
   /**
   * Method to find the average of all numbers in the array.
   * 
   * @return sum - average of nums
   */
   public double calculateAverage() {
      int sum = 0;
      
      for (int i = 0; i < numbers.length; i++) {
         sum += numbers[i];
      }
      return (double) sum / numbers.length;
   }
   
   /**
   * Method to return the array.
   * 
   * @return result - array
   */
   public String toString() {
      String result = "";
      
      for (int i = 0; i < numbers.length; i++) {
         result += numbers[i] + "\t";
      }
      
      return result;
   }
   
   /**
   * Method to return the array in reverse.
   * 
   * @return result - reversed array
   */
   public String toStringInReverse() {
      String result = "";
      
      for (int i = numbers.length - 1; i >= 0; i--) {
         result += numbers[i] + "\t";
      }
      
      return result;
   }

}