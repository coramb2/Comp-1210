import org.junit.Assert;
//import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/** 
* JUnit test for SquareAntiprism.
* 
* Project 8 
* @author Cora Baldwin 
* @version March 31, 2022 
*/
public class SquareAntiprismTest {


   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before public void setUp() {
   }
   
   /**
      *Test for creating a new object.
      */ 
   @Test public void newObjectTest() {
      SquareAntiprism ex1 = new SquareAntiprism("Small Example", 1.25);
     
      Assert.assertEquals("Small Example", ex1.getLabel());
      Assert.assertEquals("Get edge test", 1.25, ex1.getEdge(), 0.0001);
   }
   
  /**
      *Test for setLabel method.
      */
   @Test public void setLabelTest() {
      SquareAntiprism ex1 = new SquareAntiprism("Small Example", 1.25);
      
      Assert.assertEquals("Set label test", true, 
         ex1.setLabel("Small Example"));
      Assert.assertEquals("setLabelTest fail", false, ex1.setLabel(null));
   }
   
   /**
      *Test for setEdge method.
      */
   @Test public void setEdgeTest() {
      SquareAntiprism ex1 = new SquareAntiprism("Small Example", 1.25);
      
      Assert.assertEquals("Set edge test", true, ex1.setEdge(1.25));
      Assert.assertEquals("setEdgeTest fail", false, ex1.setEdge(-1));
   }
   
   /**
      *Test for height method.
      */
   @Test public void heightTest() {
      SquareAntiprism ex1 = new SquareAntiprism("Small Example", 1.25);
      
      Assert.assertEquals("Height test", 1.07536, ex1.height(), 0.0001);
   }
   
   /**
      *Test for surfaceArea method.
      */
   @Test public void surfaceAreaTest() {
      SquareAntiprism ex1 = new SquareAntiprism("Small Example", 1.25);
     
      Assert.assertEquals("Surface area test", 25.91415, 
         ex1.surfaceArea(), 0.0001);
   }
   
   /**
      *Test for volume method.
      */
   @Test public void volumeTest() {
      SquareAntiprism ex1 = new SquareAntiprism("Small Example", 1.25);
     
      Assert.assertEquals("Volume test", 8.33585, ex1.volume(), 0.0001);
   }
   
   /**
      *Test for toString method.
      */
   @Test public void toStringTest() {
      SquareAntiprism ex1 = new SquareAntiprism("Small Example", 1.25);
      
      Assert.assertEquals("To string test", true, 
         ex1.toString().contains("\"Small Example\""));
   }
   
   /**
      *Test for getCount method.
      */
   @Test public void countTest() {
      SquareAntiprism.resetCount();
   
      Assert.assertEquals("reset count test", 0, SquareAntiprism.getCount());
   
      SquareAntiprism ex1 = new SquareAntiprism("Small Example", 1.25);
      SquareAntiprism ex2 = new SquareAntiprism(" Medium Example ", 10.4);
      
      Assert.assertEquals("Get count test", 2, SquareAntiprism.getCount());
   
   }
   
   /**
   * Test for equals method.
   */
   @Test public void equalsTest() {
      SquareAntiprism ex1 = new SquareAntiprism("Example", 10);
      SquareAntiprism ex2 = new SquareAntiprism("Example2", 10);
      SquareAntiprism ex3 = new SquareAntiprism("Example", 1.25);
      String ex4 = "Example";
      
      Assert.assertEquals("equals test", true, ex1.equals(ex1));
      Assert.assertEquals("equals test fail", false, ex1.equals(ex2));
      Assert.assertEquals("equals test fail", false, ex1.equals(ex3));
      Assert.assertEquals("equals test fail", false, ex1.equals(ex4));
   }
   
   /**
      *Test for hashCode method.
      */
   @Test public void hashCodeTest() {
      SquareAntiprism ex1 = new SquareAntiprism("Small Example", 1.25);
      
      Assert.assertEquals("Hash code test", 0, ex1.hashCode());
   }
   
   /**
   *Test 1 for compareTo method.
   */
   @Test public void compareToTest1() {
      SquareAntiprism ex1 = new SquareAntiprism("Small Example", 1.25);
      SquareAntiprism ex2 = new SquareAntiprism(" Medium Example ", 10.4);
      
      Assert.assertTrue(ex1.compareTo(ex2) < 0);
   }
   
   /**
   *Test 2 for compareTo method.
   */
   @Test public void compareToTest2() {
      SquareAntiprism ex1 = new SquareAntiprism("Large Example", 32.25);
      SquareAntiprism ex2 = new SquareAntiprism(" Medium Example ", 10.4);
      
      Assert.assertTrue(ex1.compareTo(ex2) > 0);
   }
   
   /**
   *Test 3 for compareTo method.
   */
   @Test public void compareToTest3() {
      SquareAntiprism ex1 = new SquareAntiprism("Small Example", 1.25);
      SquareAntiprism ex2 = new SquareAntiprism(" Medium Example ", 1.25);
      
      Assert.assertTrue(ex1.compareTo(ex2) == 0);
   }
}
