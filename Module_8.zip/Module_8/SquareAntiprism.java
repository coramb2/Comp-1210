import java.text.DecimalFormat;

/** 
* Creates square antiprisms and has methods to calculate 
* the surface area, volume, etc.
* 
* Project 8
* @author Cora Baldwin 
* @version March 31, 2022 
*/
public class SquareAntiprism {

   //instance variables
   private String label = "";
   private double edge = 0;
   private static int count = 0;
   
   /**
   * Constructor that creates a new square antiprism.
   * 
   * @param labelIn - name
   * @param edgeIn - edge length
   */
   public SquareAntiprism(String labelIn, double edgeIn) { //checked
      setLabel(labelIn);
      setEdge(edgeIn);
      
      count++;
   }
   
  /**
   * Method to return the label name.
   * 
   * @return label - object name
   */
   public String getLabel() { //checked
      return label;
   }
   
   /**
   * Method to see if a label was set.
   * 
   * @param labelIn - user input of label
   * @return boolean - if label was made true/false
   */
   public boolean setLabel(String labelIn) { //checked
      if (labelIn != null) {
         label = labelIn.trim();
         return true;
      }
      return false;
   }
   
   /**
   * Method to return edge length.
   * 
   * @return edge - edge length
   */
   public double getEdge() { //checked
      return edge;
   }
   
   /**
   * Method to see if an edge length was set.
   * 
   * @param edgeIn - user input of edge lenth
   * @return boolean - if edge was made true/false
   */
   public boolean setEdge(double edgeIn) { //checked
      if (edgeIn >= 0) {
         edge = edgeIn;
         return true;
      }
      return false;
   }
   
   /**
   * Method to calculate height of square antiprism.
   * 
   * @return height - returns the height
   */
   public double height() { //checked
      double height = (Math.pow(1 / Math.cos(Math.PI / 16), 2)) / 4; 
      height = Math.sqrt(1 - height);
      height = height * edge;
      return height;
   }
   
   /**
   * Method to calculate the surface area of square antiprism.
   * 
   * @return surfaceArea - surface area
   */
   public double surfaceArea() { //checked
      double surfaceArea = Math.cos(Math.PI / 8) / Math.sin(Math.PI / 8);
      surfaceArea = surfaceArea + Math.sqrt(3);
      surfaceArea = 4 * surfaceArea * Math.pow(edge, 2);
      return surfaceArea;
   }
   
   /**
   * Method to calculate the volume.
   * 
   * @return volume - volume
   */
   public double volume() { //checked
      double volume = Math.sqrt(4 * Math.pow(Math.cos(Math.PI / 16), 2) - 1);
      volume = 8 * volume * Math.sin((3 * Math.PI) / 16);
      double bottom =  (12 * Math.pow(Math.sin(Math.PI / 8), 2));
      volume = volume * Math.pow(edge, 3) / bottom;
      return volume;
   }
   
   /**
   * Method to return a summary of the antiprism info.
   * 
   * @return output - summary
   */
   public String toString() { //checked
      DecimalFormat df = new DecimalFormat("#,##0.0##");
      
      String output = "SquareAntiprism \"" + label + "\" with edge of "
         + edge + " units has:\n\theight = " + df.format(height()) + " units\n"
         + "\tsurface area = " + df.format(surfaceArea()) + " square units\n\t"
         + "volume = " + df.format(volume()) + " cubic units";
      return output;
      
   }
   
   /**
   * Method to return the count of antiprisms created.
   * 
   * @return count - number of antiprisms
   */
   public static int getCount() { //checked
      return count;
   }
   
   /**
   * Method to method to reset the count.
   * 
   */
   public static void resetCount() { //checked
      count = 0;
   }
   
   /**
   * Method to check the equivalence of objects.
   * 
   * @param obj - user input of object
   * @return boolean - if equivalence was true/false
   */
   public boolean equals(Object obj) { //checked
      if (!(obj instanceof SquareAntiprism)) {
         return false;
      }
      else {
         SquareAntiprism d = (SquareAntiprism) obj;
         return (label.equalsIgnoreCase(d.getLabel())
            && (Math.abs(edge - d.getEdge()) < .000001));
      }
   }
   
   /**
   * Mandatory method.
   * 
   * @return 0 - must have
   */
   public int hashCode() { //checked
      return 0;
   }
   
   /**
   * Method to compare objects.
   *
   * @param obj - an object to compare
   * @return int - depends on <,>,=
   */
   public int compareTo(SquareAntiprism obj) {
      if (Math.abs(this.volume() - obj.volume()) < 0.000001) {
         return 0;
      }
      else if (this.volume() < obj.volume()) {
         return -1;
      }
      else {
         return 1;
      }
   }
}