import java.util.ArrayList;

/**
* Holds a set of integer values representing daily temperatures.
*
* Activity 6
* @author Cora Baldwin
* @version Feb 22, 2022
*/
public class Temperatures {
   
   //instance variable
   private ArrayList<Integer> temperatures = new ArrayList<Integer>();
   
   /**
   * Constructor that takes an ArrayList of integer values.
   * 
   * @param temperaturesIn - Takes int values
   */
   public Temperatures(ArrayList<Integer> temperaturesIn) {
   
      temperatures = temperaturesIn;
   }
   
   /**
   * Method that compares each value to get the lowest value.
   * 
   * @return low - Lowest temp
   */
   public int getLowTemp() {
      
      if (temperatures.isEmpty()) {
         return 0;
      }
      else {
         int low = temperatures.get(0);
         for (int i = 0; i < temperatures.size(); i++) {
            if (temperatures.get(i) < low) {
               low = temperatures.get(i);
            }
         }
         return low;
      }
   }
   
   /**
   * Method that compares each value to get the highest value.
   * 
   * @return high - Highest temp
   */
   public int getHighTemp() {
   
      if (temperatures.isEmpty()) {
         return 0;
      }
      else {
         int high = temperatures.get(0);
         for (Integer temp : temperatures) {
            if (temp > high) {
               high = temp;
            }
         }
         return high;
      }
   }
   
   /**
   * Method that compares user input to low and returns the lowest value.
   * 
   * @param lowIn - userInput
   * @return lowest value - Lowest temp
   */
   public int lowerMinimum(int lowIn) {
      return lowIn < getLowTemp() ? lowIn : getLowTemp();
   }
   
   /**
   * Method that compares user input to high and returns the highest value.
   * 
   * @param highIn - userInput
   * @return highest value - Highest temp
   */
   public int higherMaximum(int highIn) {
      return highIn > getHighTemp() ? highIn : getHighTemp();
   }
   
   /**
   * Method that returns info about the arraylist.
   * 
   * @return string - Info
   */
   public String toString() {
   
      return "\tTemperatures: " + temperatures
         + "\n\tLow: " + getLowTemp()
         + "\n\tHigh: " + getHighTemp();
   }
}