import java.util.Scanner;

/** 
* Reads in data, creates a Trapezohedron object, and then prints the object.
* 
* Project 4 
* @author Cora Baldwin 
* @version February 11, 2022 
*/
public class TrapezohedronApp {
   
/** 
* Takes user input to set the label, color, and short edge for a trapezohedron.
* @param args Command line arguments 
*/ 
   public static void main(String[] args) {
   
      Scanner userInput = new Scanner(System.in);
      
      System.out.println("Enter label, color, and short edge length"
         + " for a trapezohedron.");
      System.out.print("\tlabel: ");
      String label = userInput.nextLine();
      System.out.print("\tcolor: ");
      String color = userInput.nextLine();
      System.out.print("\tshort edge: ");
      double shortEdge = userInput.nextDouble();
      
      Trapezohedron trap = new Trapezohedron(label, color, shortEdge);
      
      if (shortEdge <= 0) {
         System.out.println("Error: short edge must be greater than zero.");
      }
      else {
         System.out.println("\n" + trap);
      }
   }
}