/** 
* Variables, constructor, and methods for name, location, age, and on/offline.
* 
* Activity 4 
* @author Cora Baldwin 
* @version February 8, 2022 
*/
public class UserInfo {
// instance variables
   private String firstName = "";
   private String lastName = "";
   private String location = "";
   private int age = 0;
   private int status;
   
   private static final int OFFLINE = 0, ONLINE = 1;

// constructor
/** 
* Sets variables to default.
* @param firstNameIn User's first name
* @param lastNameIn User's last name
*/
   public UserInfo(String firstNameIn, String lastNameIn) {
      firstName = firstNameIn;
      lastName = lastNameIn;
      location = "Not specified";
      age = 0;
      status = OFFLINE;
      
   }

// methods
/** 
* Converts user info into readable output.
* @return Formatted user info for name, age, location, and status
*/
   public String toString() {
      String output = "Name: " + firstName + " "
         + lastName + "\n";
      output += "Location: " + location + "\n";
      output += "Age: " + age + "\n";
      output += "Status: ";
      if (status == OFFLINE) {
         output += "Offline";
      }
      else {
         output += "Online";
      }
      
      return output;
   }
   
/** 
* Sets location.
* @param locationIn Location of user
*/    
   public void setLocation(String locationIn) {
      location = locationIn;
   
   }
   
/** 
* Tests if age is set.
* @param ageIn User age is set or not
* @return If the age is set (true) or not set (false)
*/
   public boolean setAge(int ageIn) {
      boolean isSet = false;
      if (ageIn > 0) {
         age = ageIn;
         isSet = true;
      }
      return isSet;
   }

/** 
* Returns the age of the user.
* @return Returns age 
*/
   public int getAge() {
      return age;
   }
/** 
* Returns location of user.
* @return Location 
*/
   public String getLocation() {
      return location;
   }
/** 
* If used, status is set to offline. 
*/
   public void logOff() {
      status = OFFLINE;
   }
/** 
* If used, status is set to online.
*/
   public void logOn() {
      status = ONLINE;
   }

}